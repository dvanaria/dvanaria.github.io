To compile Micromite Companion objects from source, they require BST (Brad's Spin Tool)
Enable "Eliminate unused SPIN methods" and "Non-Parallax compatible Extensions" in the Compiler Preferences.

