Updated 12/1/14

GAMEEDIT.BIN is a "work in progress" expansion of SPREDIT.BIN

GAMEEDIT is capable of loading and editing .SPR (Sprite). .FNT (Font/Tile). and .SCR (Screen) files.

ALMOST ALL KEY COMMANDS HAVE CHANGED READ THIS DOCUMENT CAREFULLY.

CTRL-M) Switch modes between sprite mode, tile mode, and screen mode editing

TAB) Choose which group of font/tiles you want to edit in tile mode.

Note: Use of "Tools" for editing font/files is disabled for now.

CTRL-A) To change sprite animation settings

ID=multi-sprite ID 0,3, FS=Frame Start, FE=Frame End, SP=speed, XP=test position X, YP=test position Y

NEW CHANGES:
Sprite & tile mode
Ctrl 1 - 8, select color 1 - 8 
Alt  1 - 8, select color 9 - 16
Ctrl e works without needing Ctrl p

Screen mode
Ctrl l & s works without hitting the tab key first
New added 4 animated sprites that can be anywhere on the screen

Sprite and screen mode
Animated sprite x,y positions are now displayed in hex 0 - FF
Ctrl - h, hide animated sprites


Screen edit mode:
=================

Use cursor keys to move around.
Pressing any tile's key will place it on screen.
Use TAB to access and select a tile to paste with SPACE to place it on the screen.
DEL) to erase a tile.
CTRL-L to load am .SCR file.
CTRL-S to save an .SCR file.

Screen mode editor allows for editing of up to a 32x32 screen.  (Two extra columns on either side)

KEYBOARD COMMANDS:
==================

CTRL-L replaces L for loading files
CTRL-S replaces S for saving files
CTRL-C replaces c for copy sprite
CTRL-V replaces v for paste sprite
CTRL-W "wipe" erase a sprite
CTRL-T replaces t for access of tool menu
CTRL-P replaces p for color select
CTRL-E replaces e for edit color
CTRL-A brings up the animation bar
CTRL-H Hide Animated Sprites

Ctrl 1 - 8, select color 1 - 8 
Alt  1 - 8, select color 9 - 16


