BST Propeller Archive
Created by Brads Spin Tool Compiler v0.15.4-pre5 - Copyright 2008,2009,2010 All rights reserved
Compiled for i386 Linux at 14:24:15 on 2010/03/10

Archive Created at 20:52:03 On 17-09-14
Included Objects : 
mode2
  |
  +--FullDuplexSerial_2k
  |
  +--keyboard
  |
  +--fsrwFemto
  |      |
  |      +----sdspiFemto
  |
  +--halfrange8x8-1font
  |
  +--tinysynth
  |
  +--I2C slave v1.0
  |
  +--strings2

Included Files : 
waitvid.50xH.driver.2048.cog
,
 - mode2.spin
 - FullDuplexSerial_2k.spin
 - Keyboard.spin
 - fsrwFemto.spin
 - sdspiFemto.spin
 - halfrange8x8-1font.spin
 - tinysynth.spin
 - I2C slave v1.0.spin
 - STRINGS2.spin
,
