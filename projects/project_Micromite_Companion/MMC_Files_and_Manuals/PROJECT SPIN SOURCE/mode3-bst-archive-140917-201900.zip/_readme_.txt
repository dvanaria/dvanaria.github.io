BST Propeller Archive
Created by Brads Spin Tool Compiler v0.15.4-pre5 - Copyright 2008,2009,2010 All rights reserved
Compiled for i386 Linux at 14:24:15 on 2010/03/10

Archive Created at 20:19:00 On 17-09-14
Included Objects : 
mode3
  |
  +--FullDuplexSerial_2k
  |
  +--keyboard
  |
  +--fsrwFemto
  |      |
  |      +----sdspiFemto
  |
  +--SLUG_VGA_Renderer
  |          |
  |          +--------SLUG_VGA_8bit
  |
  +--tinysynth
  |
  +--I2C slave v1.0
  |
  +--strings2

,
 - mode3.spin
 - FullDuplexSerial_2k.spin
 - Keyboard.spin
 - fsrwFemto.spin
 - sdspiFemto.spin
 - SLUG_VGA_Renderer.spin
 - Slug_VGA_8bit.spin
 - tinysynth.spin
 - I2C slave v1.0.spin
 - STRINGS2.spin
,
